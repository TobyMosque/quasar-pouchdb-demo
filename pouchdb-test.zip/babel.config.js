module.exports = {
  presets: [
    ['@quasar/babel-preset-app', {
      presetEnv: { modules: 'commonjs' }
    }]
  ]
}
